moni16_3\startup_stm32g431xx.o: startup_stm32g431xx.s
