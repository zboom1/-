#ifndef __HEADFILE_H__
#define __HEADFILE_H__

#include "stm32g4xx.h"                  // Device header

#include "main.h"
#include "gpio.h"

#include "stdio.h"
#include "stdint.h"
#include "string.h"

#include "fun.h"
#include "key.h"
#include "lcd.h"
#include "tim.h"
#include "adc.h"

extern uint8_t lcd_flag;
extern uint8_t hilow_flag;
extern uint8_t hilow_change;//0����1�˳�
extern uint8_t high;
extern uint16_t low;
extern uint8_t high_temp;
extern uint8_t low_temp;
extern uint8_t con;


#endif
