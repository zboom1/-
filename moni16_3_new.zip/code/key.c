#include "headfile.h"

uint8_t B1_state;
uint8_t B1_last_state;
uint8_t B2_state;
uint8_t B2_last_state;
uint8_t B3_state;
uint8_t B3_last_state;
uint8_t B4_state;
uint8_t B4_last_state;

uint8_t hilow_flag;
uint8_t hilow_change = 1;//0����1�˳�

void key_scan(void)
{
    B1_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
    B2_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1);
    B3_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2);
    B4_state = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
    if(B1_state == 0 && B1_last_state == 1)
    {
        lcd_flag ++;
        lcd_flag %= 3;
        if(lcd_flag == 1)
        {
            hilow_flag = 0;
        }
        if(lcd_flag == 2)
        {
            hilow_change = 1;
        }
    }
    if(B2_state == 0 && B2_last_state == 1)
    {
        if(lcd_flag == 2)
        {
            hilow_flag ++;
            hilow_flag %= 2;
        }
    }
    if(B3_state == 0 && B3_last_state == 1)
    {
        if(lcd_flag == 2)
        {
            hilow_change ++;
            hilow_change %= 2;
            
            if(hilow_change == 0)
            {
                high_temp = high;
                low_temp = low;
            }
            if(hilow_change)
            {
                high = high_temp;
                low = low_temp;
            }
        }
        
    }
    if(B4_state == 0 && B4_last_state == 1)
    {
        if(lcd_flag == 0)
        {
            con = 0;
        }
    }
    B1_last_state = B1_state;
    B2_last_state = B2_state;
    B3_last_state = B3_state;
    B4_last_state = B4_state;
}
