#include "headfile.h"
uint32_t capture;
uint32_t fre;
uint16_t rate;
uint8_t con;
uint8_t max;
uint8_t min;
uint8_t high = 100;
uint16_t low = 60;
uint8_t high_temp;
uint8_t low_temp;
//uint8_t high;
//uint8_t low;

void led_show(uint8_t led, uint8_t mode)
{
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
    if(mode)
    {
        HAL_GPIO_WritePin(GPIOC, (GPIO_PIN_8 << (led-1)), GPIO_PIN_RESET);
    }
    else
    {
       HAL_GPIO_WritePin(GPIOC, (GPIO_PIN_8 << (led-1)), GPIO_PIN_SET);
    }
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
}
    
char text[20];
uint8_t lcd_flag;

void heart_show(void)
{
    sprintf(text, "       HEART        ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    sprintf(text, "      Rate:%d        ",rate);
    LCD_DisplayStringLine(Line3, (uint8_t *)text);
    sprintf(text, "       Con:%d       ",con);
    LCD_DisplayStringLine(Line4, (uint8_t *)text);

//    sprintf(text, "    fre:%d  %.2f  ",fre, get_vol());
//    LCD_DisplayStringLine(Line6, (uint8_t *)text);
//    sprintf(text, "   High:%d  Low:%d      ",high,low);
//    LCD_DisplayStringLine(Line7, (uint8_t *)text);
}
void record_show(void)
{
    sprintf(text, "       RECORD       ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    sprintf(text, "       Max:%d        ",max);
    LCD_DisplayStringLine(Line3, (uint8_t *)text);
    sprintf(text, "       Min:%d       ",min);
    LCD_DisplayStringLine(Line4, (uint8_t *)text);
    
//    sprintf(text, "   High:%d  Low:%d      ",high,low);
//    LCD_DisplayStringLine(Line7, (uint8_t *)text);
}
void para_show(void)
{
    sprintf(text, "        PARA        ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    if(hilow_change == 0)
    {
        sprintf(text, "      High:%d        ",high_temp);
        LCD_DisplayStringLine(Line3, (uint8_t *)text);
        sprintf(text, "       Low:%d       ",low_temp);
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    else
    {
        sprintf(text, "      High:%d        ",high);
        LCD_DisplayStringLine(Line3, (uint8_t *)text);
        sprintf(text, "       Low:%d       ",low);
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    
//    sprintf(text, "   High:%d  Low:%d      ",high,low);
//    LCD_DisplayStringLine(Line7, (uint8_t *)text);
        
}

void lcd_show(void)
{
    switch(lcd_flag)
    {
        case 0:
            heart_show();
            break;
        case 1:
            record_show();
            break;
        case 2:
            para_show();
            break;
        default:
            break;
    }
}


double get_vol(void)
{
    HAL_ADC_Start(&hadc2);
    uint32_t adc_value = HAL_ADC_GetValue(&hadc2);
    return 3.3 * adc_value / 4096;
}

uint8_t initial_flag;
uint8_t con_flag = 1;//�Ķ�
uint8_t led_state;
uint8_t timer_5s;

uint8_t last_alarm_state;//�Ķ�

void change(void)
{
    
    if(hilow_flag == 0 && hilow_change ==0)
    {
        if(get_vol() < 1)
        {
            high_temp = 60;
        }
        else if(get_vol() >= 1 && get_vol() <= 3)
        {
            high_temp = 45 * get_vol() +15;
        }
        else if(get_vol() > 3)
        {
            high_temp = 150;
        }
    }
    else if(hilow_flag == 1 && hilow_change ==0)
    {
        if(get_vol() < 1)
        {
            low_temp = 60;
        }
        else if(get_vol() >= 1 && get_vol() <= 3)
        {
            low_temp = 45 * get_vol() +15;
        }
        else if(get_vol() > 3)
        {
            low_temp = 150;
        }

    }
    if(initial_flag)
    {
        //�������ӣ��Ķ�
        uint8_t current_alarm_state;
        if (rate < low)
        {
            current_alarm_state = 1;
        } 
        else if (rate > high)
        {
            current_alarm_state = 2;
        }
        else
        {
            current_alarm_state = 0;
        }

        // �������״̬�����仯����ӵ������޵��������ޣ�������con_flag
        if (current_alarm_state != last_alarm_state)
        {
            con_flag = 0;
            last_alarm_state = current_alarm_state;
        }
        //�������ӣ��Ķ�
    
    
        if(rate>=low && rate<=high)
        {
            con_flag = 0;
        }
        if(rate > high && con_flag == 0)
        {
            con ++;
            con_flag = 1;
            led_state = 1;
            timer_5s = 0;

        }
        if(rate < low && con_flag == 0)
        {
            con ++;
            con_flag = 1;
            led_state = 1;
            timer_5s = 0;
        }
    }

    if(rate > max)
    {
        max = rate; 
    }
    if(rate < min)
    {
        min = rate; 
    }
    
    if(lcd_flag == 0)led_show(1,1);
    else led_show(1,0);
    if(lcd_flag == 1)led_show(2,1);
    else led_show(2,0);
    if(lcd_flag == 2)led_show(3,1);
    else led_show(3,0);
    
    if(hilow_change == 0 && hilow_flag == 0)led_show(4,1);
    else led_show(4,0);
    if(hilow_change == 0 && hilow_flag == 1)led_show(5,1);
    else led_show(5,0);
    
    led_show(6, led_state);
    
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
//    if(htim->Instance == TIM16)
//    {
//        capture = HAL_TIM_ReadCapturedValue(&htim16, TIM_CHANNEL_1);
//        TIM16->CNT = 0;
//        fre = 1000000 / capture;
//    }
    if(htim->Instance == TIM3)
    {
        capture = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_1) + 1;
        fre = 1000000 / capture;
    }
}

uint8_t timer_200ms;


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM2)
    {
        if(fre < 1000)
        {
            rate = 30;
        }
        else if(fre >= 1000 &&fre <= 2000)
        {
            rate = (uint16_t)(0.17f * fre - 140 + 0.5f);//�Ķ�
        }
        else if(fre > 2000)
        {
            rate = 200;
        }
    }
    if(initial_flag == 0)
    {
        timer_200ms++;
        if(timer_200ms >= 2)
        {
            initial_flag = 1;
            max = rate;
            min = rate; 
            
            if (rate < low)
            {
                last_alarm_state = 1;
            } 
            else if (rate > high)
            {
                last_alarm_state = 2;
            }
            else
            {
                last_alarm_state = 0;
            }
        }
    }
    if(led_state)
    {
        timer_5s ++;
        if(timer_5s >=50)
        {
            timer_5s = 0;
            led_state = 0;
        }
    }
}

