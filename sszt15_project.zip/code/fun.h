#ifndef __FUN_H__
#define __FUN_H__

void led_show(uint8_t led, uint8_t mode);
void lcd_show(void);
void data_show(void);

void change(void);


#endif
