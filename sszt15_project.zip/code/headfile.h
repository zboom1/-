#ifndef __HEADFILE_H__
#define __HEADFILE_H__

#include "stm32g4xx.h"                  // Device header
#include "stdio.h"
#include "stdint.h"
#include "string.h"

#include "main.h"
#include "gpio.h"
#include "tim.h"

#include "key.h"
#include "fun.h"
#include "handler.h"
#include "lcd.h"

extern uint32_t freA_meature;
extern uint32_t freB_meature;
extern int PX;

extern int freA;
extern int freB;
extern uint8_t data_mode;

extern uint8_t lcd_flag;//0���ݽ��� 1�������� 2ͳ�ƽ���
extern uint8_t NDA,NDB;
extern uint8_t NHA,NHB;
extern uint16_t PD;
extern uint16_t PH;

extern uint8_t B3_pressd;
extern uint16_t B3_press_duration;

#endif
