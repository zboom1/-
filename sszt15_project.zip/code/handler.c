#include "headfile.h"

uint32_t freA_meature;
uint32_t freB_meature;
uint32_t captureA;
uint32_t captureB;

int freA;
int freB;

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM2)
    {
        captureA = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1) + 1;
        freA_meature = 1000000/captureA;
    }
    if(htim->Instance == TIM3)
    {
        captureB = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_1) + 1;
        freB_meature = 1000000/captureB;
    }
}

uint16_t timer_100ms;
uint16_t timerA_3s;
uint16_t timerB_3s;

int freA_max,freA_min;
int freB_max,freB_min;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)//10ms
{
    if(htim->Instance == TIM6)
    {
        timer_100ms ++;
        if(timer_100ms >= 10)//100ms
        {
            timer_100ms = 0;
            freA = freA_meature + PX;
            freB = freB_meature + PX;
        }
    }
    if(B3_pressd)
    {
        B3_press_duration ++;
    }
    
    if(freA > 0)
    {
        if(timerA_3s == 0)
        {
            freA_max = freA;
            freA_min = freA;
        }
        else
        {
            if(freA > freA_max) freA_max = freA;
            if(freA < freA_min) freA_min = freA;
        }
        timerA_3s ++;
    }
    
    if(freB >0)
    {
        if(timerB_3s == 0)
        {
            freB_max = freB;
            freB_min = freB;
        }
        else
        {
            if(freB > freB_max) freB_max = freB;
            if(freB < freB_min) freB_min = freB;
        }
        timerB_3s ++;
    }   
    
    if(timerA_3s >= 300)//3s
    {
        timerA_3s = 0;
        if((freA_max - freA_min)> PD) NDA++;
        freA_max = freA;
        freA_min = freA;
    }
    if(timerB_3s >= 300)//3s
    {
        timerB_3s = 0;
        if((freB_max - freB_min)> PD) NDB++;
        freB_max = freB;
        freB_min = freB;
    }
}

