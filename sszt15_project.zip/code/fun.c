#include "headfile.h"

uint16_t PD = 1000;
uint16_t PH = 5000;
int PX;

uint8_t NDA,NDB;
uint8_t NHA,NHB;

void led_show(uint8_t led, uint8_t mode)
{
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
    if(mode)
    {
        HAL_GPIO_WritePin(GPIOC, (GPIO_PIN_8 << (led - 1)), GPIO_PIN_RESET);
    }
    else
    {
        HAL_GPIO_WritePin(GPIOC, (GPIO_PIN_8 << (led - 1)), GPIO_PIN_SET);
    }
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
}

char text[20];
uint8_t data_mode;
void data_show(void)
{
    sprintf(text, "        DATA        ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    if(data_mode == 0)
    {
        if(freA < 0)
        {
            sprintf(text, "     A=NULL        ");
        }
        else if(freA >=0 && freA < 1000)
        {
            sprintf(text, "     A=%dHz        ", freA);
        }
        else
        {
            float freA_temp = freA / 1000.0;
            sprintf(text, "     A=%.2fKHz        ", freA_temp);
        }
        LCD_DisplayStringLine(Line3, (uint8_t *)text);
        
        if(freB < 0)
        {
            sprintf(text, "     B=NULL        ");
        }
        else if(freB >=0 && freB < 1000)
        {
            sprintf(text, "     B=%dHz        ", freB);
        }
        else
        {
            float freB_temp = freB / 1000.0;
            sprintf(text, "     B=%.2fKHz        ", freB_temp);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    else if(data_mode == 1)
    {
        float freA_T = 1.0 /freA * 1000000;
        float freB_T = 1.0 /freB * 1000000;
        if(freA_T < 0)
        {
            sprintf(text, "     A=NULL        ");
        }
        else if(freA_T >=0 && freA_T < 1000)
        {
            sprintf(text, "     A=%duS        ", (uint32_t)freA_T);
        }
        else
        {
            freA_T = freA_T / 1000;
            sprintf(text, "     A=%.2fmS        ", freA_T);
        }
        LCD_DisplayStringLine(Line3, (uint8_t *)text);
        
        if(freB_T < 0)
        {
            sprintf(text, "     B=NULL        ");
        }
        else if(freB_T >=0 && freB_T < 1000)
        {
            sprintf(text, "     B=%duS        ", (uint32_t)freB_T);
        }
        else
        {
            freB_T = freB_T / 1000;
            sprintf(text, "     B=%.2fmS        ", freB_T);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    sprintf(text, "                    ");
    LCD_DisplayStringLine(Line5, (uint8_t *)text);
    sprintf(text, "                    ");
    LCD_DisplayStringLine(Line6, (uint8_t *)text);
}

void para_show(void)
{
    sprintf(text, "        PARA        ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    
    sprintf(text, "     PD=%dHz        ", PD);
    LCD_DisplayStringLine(Line3, (uint8_t *)text);
    sprintf(text, "     PH=%dHz        ", PH);
    LCD_DisplayStringLine(Line4, (uint8_t *)text);
    sprintf(text, "     PX=%dHz        ", PX);
    LCD_DisplayStringLine(Line5, (uint8_t *)text);
    sprintf(text, "                    ");
    LCD_DisplayStringLine(Line6, (uint8_t *)text);
}
void recd_show(void)
{
    sprintf(text, "        RECD        ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    
    sprintf(text, "     NDA=%d        ", NDA);
    LCD_DisplayStringLine(Line3, (uint8_t *)text);
    sprintf(text, "     NDB=%d        ", NDB);
    LCD_DisplayStringLine(Line4, (uint8_t *)text);
    sprintf(text, "     NHA=%d        ", NHA);
    LCD_DisplayStringLine(Line5, (uint8_t *)text);
    sprintf(text, "     NHB=%d        ", NHB);
    LCD_DisplayStringLine(Line6, (uint8_t *)text);
}

uint8_t lcd_flag;//0���ݽ��� 1�������� 2ͳ�ƽ���
void lcd_show(void)
{
    switch(lcd_flag)
    {
        case 0:
            data_show();
            break;
        case 1:
            para_show();
            break;
        case 2:
            recd_show();
            break;
        default:
            break;
    }
}

uint8_t NHA_flag, NHB_flag;

void change(void)
{
    if(NHA_flag == 0)
    {
        if(freA > PH)
        {
            NHA ++;
            NHA_flag = 1;
        }
    }
    else
    {
        if(freA <= PH)NHA_flag = 0;
    }
    
    if(NHB_flag == 0)
    {
        if(freB > PH)
        {
            NHB ++;
            NHB_flag = 1;
        }
    }
    else
    {
        if(freB <= PH)NHB_flag = 0;
    }
    
    if(lcd_flag == 0)led_show(1, 1);
    else led_show(1, 0);
    
    if(freA > PH)led_show(2, 1);
    else led_show(2, 0);
    if(freB > PH)led_show(3, 1);
    else led_show(3, 0);
        
    if((NDA >= 3) || (NDB >= 3))led_show(8, 1);
    else led_show(8, 0);
}
