#include "headfile.h"

uint8_t B1_state;
uint8_t B1_last_state;
uint8_t B2_state;
uint8_t B2_last_state;
uint8_t B3_state;
uint8_t B3_last_state;
uint8_t B4_state;
uint8_t B4_last_state;

uint8_t para_select;

uint8_t B3_pressd;
uint16_t B3_press_duration;

void key_scan(void)
{
    B1_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
    B2_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1);
    B3_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2);
    B4_state = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
    if(B1_state == 0 && B1_last_state == 1)
    {
        if(lcd_flag == 1)
        {
            switch(para_select)
            {
                case 0:
                    PD += 100;
                    if(PD >= 1000)PD = 1000;
                break;
                case 1:
                    PH += 100;
                    if(PH >= 10000)PH = 10000;
                break;
                case 2:
                    PX += 100;
                    if(PX >= 1000)PX = 1000;
                break;
            }
        }
    }
    if(B2_state == 0 && B2_last_state == 1)
    {
        if(lcd_flag == 1)
        {
            switch(para_select)
            {
                case 0:
                    PD -= 100;
                    if(PD <= 100)PD = 100;
                break;
                case 1:
                    PH -= 100;
                    if(PH <= 1000)PH = 1000;
                break;
                case 2:
                    PX -= 100;
                    if(PX <= -1000)PX = -1000;
                break;
            }
        }
    }
    if(B3_state == 0 && B3_last_state == 1)
    {
        if(lcd_flag == 0)
        {
            data_mode ++;
            data_mode %= 2;
        }
        else if(lcd_flag == 1)
        {
            para_select ++;
            para_select %= 3;
        }
        else if(lcd_flag == 2)
        {
            B3_pressd = 1;
            B3_press_duration = 0;
        }
    }
    else if(B3_state == 1 && B3_last_state == 0)
    {
        if(B3_press_duration > 100)
        {
            NHA = 0;
            NHB = 0;
            NDA = 0;
            NDB = 0;
        }
    }
    if(B4_state == 0 && B4_last_state == 1)
    {
        lcd_flag ++;
        lcd_flag %= 3;
        if(lcd_flag == 1)
        {
            para_select = 0;
        }
        if(lcd_flag == 0)
        {
            data_mode = 0;
        }
    }
    B1_last_state = B1_state;
    B2_last_state = B2_state;
    B3_last_state = B3_state;
    B4_last_state = B4_state;
}
