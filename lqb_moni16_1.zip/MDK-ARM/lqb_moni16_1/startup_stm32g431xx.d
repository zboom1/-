lqb_moni16_1\startup_stm32g431xx.o: startup_stm32g431xx.s
