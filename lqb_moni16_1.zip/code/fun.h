#ifndef __FUN_H__
#define __FUN_H__

void lock_show(void);
void set_show(void);
double get_vol(void);
void set_password(void);
void eeprom_write(uint8_t addr, uint8_t byte);
uint8_t eeprom_read(uint8_t addr);

#endif
