#ifndef __HEADFILE_H__
#define __HEADFILE_H__

#include "stm32g4xx.h"                  // Device header
#include "string.h"
#include "stdint.h"
#include "stdio.h"

#include "main.h"
#include "gpio.h"
#include "adc.h"
#include "tim.h"

#include "fun.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "i2c_hal.h"

extern uint8_t word[3];
extern uint8_t password[3];
extern uint8_t count;

extern uint8_t show_flag;//0������棬1�޸Ľ���

extern uint8_t time_flag;
extern uint32_t time_3s;

#endif
