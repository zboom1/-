#ifndef __LED_H__
#define __LED_H__

void led_show(uint8_t led, uint8_t mode);

#endif
