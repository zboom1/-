#include "headfile.h"

uint8_t B1_state;
uint8_t B1_last_state;

uint8_t word[3];//���������
uint8_t password[3] = {0, 1, 2};//����eeprom������

uint8_t count;

uint8_t show_flag;//0������棬1�޸Ľ���

uint8_t time_flag;
uint32_t time_3s;

void key_scan(void)
{
    B1_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
    if(B1_state == 0 && B1_last_state == 1)
    {
        if(show_flag == 0)
        {
            if(get_vol() < 1.5)
            {
                word[count] = 0;
            }
            else if(get_vol() >= 1.5 && get_vol() <= 2.5)
            {
                word[count] = 1;
            }
            else 
            {
                word[count] = 2;
            }
            
            if(count == 2)
            {
                if(password[0] == word[0] && password[1] == word[1] && password[2] == word[2])
                {
                    show_flag = 1;
                    time_flag = 1;
                    time_3s = 0;
                }
            }
            
            count ++;
            count %= 3;
        }
        else if(show_flag == 1)
        {
            time_flag = 0;
            if(get_vol() < 1.5)
            {
                word[count] = 0;
            }
            else if(get_vol() >= 1.5 && get_vol() <= 2.5)
            {
                word[count] = 1;
            }
            else 
            {
                word[count] = 2;
            }
            
            if(count == 2)
            {
                for(uint8_t i=0; i<3 ;i++)
                {
                    password[i] = word[i];
                }
                set_password();
                show_flag = 0;
            }
            count ++;
            count %= 3;
        }
        
        
    }
    B1_last_state = B1_state;
}
