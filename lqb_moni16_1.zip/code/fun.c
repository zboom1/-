#include "headfile.h"

char text[20];

void lock_show(void)
{
    sprintf(text, "        Lock        ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    sprintf(text, "      Pass Word     ");
    LCD_DisplayStringLine(Line3, (uint8_t *)text);
    
    if(get_vol() < 1.5)
    {
        if(count == 0)
        {
            sprintf(text, "        %d * *       ",0);
        }
        else if(count == 1)
        {
            sprintf(text, "        %d %d *       ", word[0], 0);
        }
        else if(count == 2)
        {
            sprintf(text, "        %d %d %d       ", word[0], word[1], 0);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    else if(get_vol() >= 1.5 && get_vol() <= 2.5)
    {
        if(count == 0)
        {
            sprintf(text, "        %d * *       ",1);
        }
        else if(count == 1)
        {
            sprintf(text, "        %d %d *       ", word[0], 1);
        }
        else if(count == 2)
        {
            sprintf(text, "        %d %d %d       ", word[0], word[1], 1);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    else 
    {
        if(count == 0)
        {
            sprintf(text, "        %d * *       ",2);
        }
        else if(count == 1)
        {
            sprintf(text, "        %d %d *       ", word[0], 2);
        }
        else if(count == 2)
        {
            sprintf(text, "        %d %d %d       ", word[0], word[1], 2);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
}

void set_show(void)
{
    sprintf(text, "        Set         ");
    LCD_DisplayStringLine(Line1, (uint8_t *)text);
    sprintf(text, "       Change       ");
    LCD_DisplayStringLine(Line3, (uint8_t *)text);
    

    if(get_vol() < 1.5)
    {
        if(count == 0)
        {
            sprintf(text, "       %d * *        ", 0);
        }
        else if(count == 1)
        {
            sprintf(text, "       %d %d *        ", word[0], 0);
        }
        else if(count == 2)
        {
            sprintf(text, "       %d %d %d        ", word[0], word[1], 0);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    else if(get_vol() >= 1.5 && get_vol() <= 2.5)
    {
        if(count == 0)
        {
            sprintf(text, "       %d * *        ", 1);
        }
        else if(count == 1)
        {
            sprintf(text, "       %d %d *        ", word[0], 1);
        }
        else if(count == 2)
        {
            sprintf(text, "       %d %d %d        ", word[0], word[1], 1);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
    else 
    {
        if(count == 0)
        {
            sprintf(text, "       %d * *        ", 2);
        }
        else if(count == 1)
        {
            sprintf(text, "       %d %d *        ", word[0], 2);
        }
        else if(count == 2)
        {
            sprintf(text, "       %d %d %d        ", word[0], word[1], 2);
        }
        LCD_DisplayStringLine(Line4, (uint8_t *)text);
    }
}

void set_password(void)
{
    eeprom_write(0x00, password[0]);
    eeprom_write(0x01, password[1]);
    eeprom_write(0x02, password[2]);
}

uint32_t adc_value;
double get_vol(void)
{
    HAL_ADC_Start(&hadc2);
    adc_value = HAL_ADC_GetValue(&hadc2);
    return 3.3 * adc_value / 4096;
}

void eeprom_write(uint8_t addr, uint8_t byte)
{
    I2CStart();
    I2CSendByte(0xA0);
    I2CWaitAck();
    I2CSendByte(addr);
    I2CWaitAck();
    I2CSendByte(byte);
    I2CWaitAck();
    I2CStop();
    
    HAL_Delay(20);
}

uint8_t eeprom_read(uint8_t addr)
{
    I2CStart();
    I2CSendByte(0xA0);
    I2CWaitAck();
    I2CSendByte(addr);
    I2CWaitAck();
    
    I2CStart();
    I2CSendByte(0xA1);
    I2CWaitAck();
    uint8_t data = I2CReceiveByte();
    I2CSendNotAck();
    I2CStop();
    
    return data;
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM2)
    {
        if(time_flag)
        {
            time_3s ++;
            if(time_3s >= 300)
            {
                time_3s = 0;
                show_flag = 0;
                time_flag = 0;
                count = 0;
            }
        }
    }
}

